package com.dqd.stratege;

public interface Comparable {
	public int ComparableTo(Object o);

}
