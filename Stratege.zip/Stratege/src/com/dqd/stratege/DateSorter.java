package com.dqd.stratege;

public class DateSorter {
	public static void sort(Object[] arr){
		for(int i = 0;i < arr.length;++ i){
			for(int j = 0;j < i;++ j){
				Comparable o1 = (Comparable)arr[i];
				Comparable o2 = (Comparable)arr[j];
				if(o1.ComparableTo(o2)==-1){
					Object tmp = arr[i];
					arr[i] = arr[j];
					arr[j] =tmp; 
				}
			}
		}
	}
	
	public static void sort(int[] arr){
		for(int i = 0;i<arr.length;++ i){
			for(int j = 0;j < i;++ j){
				if(arr[i]<arr[j]){
					int tmp = arr[i];
					arr[i] = arr[j];
					arr[j] = tmp;
				}
			}
		}
	}

	public static void p(int[] arr) {
		// TODO Auto-generated method stub
		for(int i = 0;i< arr.length;++ i){
			System.out.print(arr[i] +" ");
		}
	}
}
