package com.dqd.stratege;

public interface Comparator {
	//默认都是public的
	int compare(Object o1,Object o2);
}