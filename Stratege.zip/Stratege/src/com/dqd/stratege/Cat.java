package com.dqd.stratege;

import CatHeightCompare.CatHeightCompare;
import CatHeightCompare.CatWeightCompare;

public class Cat implements Comparable{
	private int height;
	
	private int weight;
	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}
	public Cat(int height,int weight) {
		super();
		this.height = height;
		this.weight = weight;
		// TODO Auto-generated constructor stub
	}
	@Override
	public int ComparableTo(Object o){
		return new CatWeightCompare().compare(this, o);
	}
}	
