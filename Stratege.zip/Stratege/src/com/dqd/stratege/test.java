package com.dqd.stratege;

public class test {
	public static void main(String[] args) {
		Cat[] arr = {new Cat(1,2),new Cat(5,7),new Cat(2,2)};
		DateSorter.sort(arr);
		//DateSorter.p(arr);
		for(int i = 0;i<arr.length;++ i){
			System.out.println(arr[i].getWeight());
		}
//		Dog[] arr = {new Dog(2),new Dog(5),new Dog(3)};
//		DateSorter.sort(arr);
//		for(int i = 0;i<arr.length;++ i){
//			System.out.println(arr[i].getFood());
//		}
	}
}
