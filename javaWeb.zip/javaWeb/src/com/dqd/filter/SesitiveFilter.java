package com.dqd.filter;

public class SesitiveFilter implements Filter {

	@Override
	public void dpFilter(Request req,Response rep,FilterChain chain) {
		req.resquestStr = req.resquestStr
				.replace("被就业", "就业")+"Ses req";
		chain.doFilter(req, rep, chain);
		rep.responseStr +="Ses solve"+'\n'; 
	}

}
