package com.dqd.filter;

import java.util.ArrayList;
import java.util.List;

public class FilterChain{
	List<Filter> filters = new ArrayList<Filter>();
	public FilterChain add(Filter f){
		this.filters.add(f);
		return this;
	}
	int index = 0;
	public void doFilter(Request req,Response rep,FilterChain chain){
		if(filters.size()==index) return;
		Filter f = filters.get(index);
		index++;
		f.dpFilter(req,rep,chain);
	}
}
