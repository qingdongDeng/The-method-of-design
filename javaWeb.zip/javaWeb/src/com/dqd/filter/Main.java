package com.dqd.filter;

public class Main {

	public static void main(String[] args) {
		String msg = "大家好:),<script>,敏感，被就业，网络没感觉，因为看不见大伙";
		Request req = new Request();
		req.setResquestStr(msg);
			
		Response rep = new Response();
		rep.setResponseStr("response");
		
		FilterChain fc = new FilterChain();
		fc.add(new HTMLFilter())
		.add(new SesitiveFilter());
		
		fc.doFilter(req, rep ,fc);
		System.out.print(req.getResquestStr()+'\n'+"    "+rep.getResponseStr());
	}
}