package com.dqd.filter;

public class HTMLFilter implements Filter {
	@Override
	public void dpFilter(Request req,Response rep,FilterChain chain) {
		req.resquestStr = req.resquestStr
				.replace(">","]").replace("<", "[")+"HTML req"+'\n';
		chain.doFilter(req, rep, chain);
		rep.responseStr += "HTML solve"+'\n';
	}
}
