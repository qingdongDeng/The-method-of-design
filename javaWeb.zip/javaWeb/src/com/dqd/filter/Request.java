package com.dqd.filter;

public class Request {
	String resquestStr;
	
	public String getResquestStr() {
		return resquestStr;
	}
	
	public void setResquestStr(String resquestStr) {
		this.resquestStr = resquestStr;
	}
	
}
