package com.dqd.filter;

public interface Filter {
	public void  dpFilter(Request req,Response rep,FilterChain chain);
}
